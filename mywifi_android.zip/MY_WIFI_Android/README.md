# MY WIFI — application Android native

Projet Android natif Kotlin + Jetpack Compose, interface française.

## État réel de cette version

Cette version constitue le premier incrément natif :
- écran d'accueil et navigation mobile ;
- ajout/suppression locale de routeurs (maximum affiché : 10) ;
- création de profils personnalisés (nom, validité, prix, débit, limite de données) ;
- génération et suppression de codes de tickets locaux ;
- écrans de rapports, activités, portail captif et réglages.

**Limites importantes :** les profils et tickets sont actuellement stockés uniquement en mémoire pendant la session. Les chiffres de tableau de bord/rapports et quelques cartes restent des exemples d'interface. Cette version ne se connecte pas encore à un vrai MikroTik, ne crée pas les profils/tickets sur le routeur et ne permet pas encore l'administration distante. Ne l'utilise pas pour gérer un réseau de production.

## Obtenir l'APK sans ordinateur

Le projet contient un workflow GitHub Actions qui compile l'APK sur un runner Linux gratuit pour un dépôt public.

1. Sur ton téléphone, ouvre GitHub et crée un dépôt **public** nommé `MY-WIFI`.
2. Téléverse le contenu de ce dossier dans le dépôt en gardant les dossiers et fichiers à leurs emplacements, notamment `.github/workflows/android.yml`.
3. Ouvre l'onglet **Actions**, sélectionne **Build MY WIFI Android APK**, puis **Run workflow** si le workflow ne démarre pas automatiquement.
4. Quand l'exécution est terminée avec succès, ouvre-la et télécharge l'artefact **MY-WIFI-debug-APK**.
5. Décompresse l'artefact sur le téléphone, puis ouvre `app-debug.apk` pour l'installer. Android peut demander d'autoriser l'installation depuis cette source.

Le dépôt doit rester public pour bénéficier du quota gratuit GitHub Actions dans les conditions habituelles. GitHub peut modifier ses limites.

## Construire localement

Prérequis : JDK 17, Gradle 8.9, Android SDK avec `platforms;android-35` et `build-tools;35.0.0`.

```bash
gradle --no-daemon assembleDebug
```

APK : `app/build/outputs/apk/debug/app-debug.apk`.

## Pour la version SaaS complète

Il faudra encore développer et tester : authentification téléphone/e-mail, essais de 30 jours et abonnements, stockage persistant, backend HTTPS, autorisations par compte, connecteur RouterOS, statistiques réelles, gestion complète des tickets/profils, portail captif et accès distant sécurisé. Pour l'accès distant, ne pas exposer directement l'API MikroTik à Internet ; utiliser un relais/tunnel sécurisé et chiffrer les secrets.
