package com.mywifi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF0A1020)
private val Panel = Color(0xFF121B2D)
private val Panel2 = Color(0xFF19253A)
private val Mint = Color(0xFF38E0B5)
private val Muted = Color(0xFF9AA8BC)
private val White = Color(0xFFF4F7FB)
private val Orange = Color(0xFFFFB86B)

private data class HotspotProfile(val name: String, val validity: String, val price: String, val speed: String, val dataLimit: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyWifiApp() }
    }
}

private data class NavItem(val label: String, val icon: ImageVector)
private val navItems = listOf(
    NavItem("Accueil", Icons.Default.Dashboard),
    NavItem("Routeurs", Icons.Default.Router),
    NavItem("Tickets", Icons.Default.ConfirmationNumber),
    NavItem("Profils", Icons.Default.Tune),
    NavItem("Activités", Icons.Default.Timeline),
    NavItem("Ventes & rapports", Icons.Default.BarChart),
    NavItem("Portail captif", Icons.Default.Web),
    NavItem("Paramètres", Icons.Default.Settings)
)

@Composable
fun MyWifiApp() {
    var selected by remember { mutableStateOf("Accueil") }
    var showAddRouter by remember { mutableStateOf(false) }
    var showTicketDialog by remember { mutableStateOf(false) }
    var routerName by remember { mutableStateOf("") }
    var ticketCount by remember { mutableIntStateOf(25) }
    var selectedProfile by remember { mutableStateOf("24 heures") }
    var showProfileDialog by remember { mutableStateOf(false) }
    var profileName by remember { mutableStateOf("") }
    var profileValidity by remember { mutableStateOf("24h") }
    var profilePrice by remember { mutableStateOf("5000") }
    var profileSpeed by remember { mutableStateOf("5M/5M") }
    var profileData by remember { mutableStateOf("Illimité") }
    val profiles = remember { mutableStateListOf(
        HotspotProfile("3 heures", "3h", "2000", "2M/2M", "Illimité"),
        HotspotProfile("24 heures", "24h", "5000", "5M/5M", "Illimité"),
        HotspotProfile("7 jours", "7d", "25000", "5M/5M", "Illimité"),
        HotspotProfile("30 jours", "30d", "70000", "5M/5M", "Illimité")
    ) }
    val routers = remember { mutableStateListOf<String>() }
    val tickets = remember { mutableStateListOf<String>() }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Mint, onPrimary = Ink, background = Ink, surface = Panel,
            onSurface = White, secondary = Orange
        )
    ) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = White) {
                    listOf(navItems[0], navItems[1], navItems[2], navItems[5]).forEach { item ->
                        NavigationBarItem(
                            selected = selected == item.label,
                            onClick = { selected = item.label },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label, fontSize = 10.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Ink, selectedTextColor = Mint,
                                indicatorColor = Mint, unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).background(Ink)
            ) {
                TopHeader()
                when (selected) {
                    "Accueil" -> Dashboard(
                        routers = routers,
                        onAddRouter = { showAddRouter = true },
                        onNavigate = { selected = it }
                    )
                    "Routeurs" -> RouterScreen(routers, onAddRouter = { showAddRouter = true })
                    "Tickets" -> TicketScreen(tickets, profiles, onGenerate = { showTicketDialog = true }, onDelete = { tickets.remove(it) })
                    "Profils" -> ProfilesScreen(profiles, onAdd = { showProfileDialog = true })
                    "Activités" -> ActivityScreen()
                    "Ventes & rapports" -> ReportsScreen()
                    "Portail captif" -> PortalScreen()
                    else -> SettingsScreen()
                }
            }
        }

        if (showAddRouter) {
            AlertDialog(
                onDismissRequest = { showAddRouter = false },
                title = { Text("Ajouter un routeur") },
                text = {
                    Column {
                        Text("Maximum : 10 routeurs par compte.", color = Muted)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = routerName, onValueChange = { routerName = it },
                            label = { Text("Nom de la zone") }, singleLine = true
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (routerName.isNotBlank() && routers.size < 10) routers.add(routerName.trim())
                        routerName = ""; showAddRouter = false
                    }) { Text("Ajouter") }
                },
                dismissButton = { TextButton(onClick = { showAddRouter = false }) { Text("Annuler") } },
                containerColor = Panel, titleContentColor = White, textContentColor = Muted
            )
        }

        if (showProfileDialog) {
            AlertDialog(
                onDismissRequest = { showProfileDialog = false },
                title = { Text("Créer un profil Hotspot") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(profileName, { profileName = it }, label = { Text("Nom du profil") }, singleLine = true)
                        OutlinedTextField(profileValidity, { profileValidity = it }, label = { Text("Validité (ex. 3h, 24h, 7d, 30d)") }, singleLine = true)
                        OutlinedTextField(profilePrice, { profilePrice = it.filter(Char::isDigit) }, label = { Text("Prix en FG") }, singleLine = true)
                        OutlinedTextField(profileSpeed, { profileSpeed = it }, label = { Text("Débit (ex. 5M/5M)") }, singleLine = true)
                        OutlinedTextField(profileData, { profileData = it }, label = { Text("Limite data (ex. 2G ou Illimité)") }, singleLine = true)
                        Text("Profil enregistré dans cette session de l'application.", color = Orange, fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (profileName.isNotBlank() && profileValidity.isNotBlank()) {
                            profiles.add(HotspotProfile(profileName.trim(), profileValidity.trim(), profilePrice.ifBlank { "0" }, profileSpeed.ifBlank { "Illimité" }, profileData.ifBlank { "Illimité" }))
                            selectedProfile = profileName.trim()
                        }
                        profileName = ""; profileValidity = "24h"; profilePrice = "5000"; profileSpeed = "5M/5M"; profileData = "Illimité"
                        showProfileDialog = false
                    }) { Text("Enregistrer") }
                },
                dismissButton = { TextButton(onClick = { showProfileDialog = false }) { Text("Annuler") } },
                containerColor = Panel, titleContentColor = White, textContentColor = Muted
            )
        }

        if (showTicketDialog) {
            AlertDialog(
                onDismissRequest = { showTicketDialog = false },
                title = { Text("Générer des tickets") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Nombre de tickets")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { if (ticketCount > 1) ticketCount-- }) { Text("−") }
                            Text("$ticketCount", Modifier.padding(horizontal = 20.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            OutlinedButton(onClick = { if (ticketCount < 500) ticketCount++ }) { Text("+") }
                        }
                        Text("Profil")
                        profiles.forEach { profile ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selectedProfile == profile.name, onClick = { selectedProfile = profile.name })
                                Text("${profile.name} · ${profile.price} FG", color = White)
                            }
                        }
                        Text("Les codes sont créés localement. Ils ne sont pas encore envoyés au MikroTik.", color = Orange, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        repeat(ticketCount.coerceAtMost(500)) {
                            val code = (1..8).map { "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".random() }.joinToString("")
                            tickets.add(0, "$code · $selectedProfile · Disponible")
                        }
                        showTicketDialog = false
                    }) { Text("Créer") }
                },
                dismissButton = { TextButton(onClick = { showTicketDialog = false }) { Text("Annuler") } },
                containerColor = Panel, titleContentColor = White, textContentColor = Muted
            )
        }
    }
}

@Composable
private fun TopHeader() {
    Row(
        Modifier.fillMaxWidth().background(Ink).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Mint, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Wifi, contentDescription = null, tint = Ink, modifier = Modifier.size(25.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("MY WIFI", fontSize = 21.sp, fontWeight = FontWeight.Black, color = White, letterSpacing = 1.2.sp)
                Text("HOTSPOT CONTROL", fontSize = 9.sp, color = Mint, letterSpacing = 2.sp)
            }
        }
        Box(Modifier.size(42.dp).background(Panel2, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, contentDescription = "Compte", tint = White)
        }
    }
}

@Composable
private fun Dashboard(routers: List<String>, onAddRouter: () -> Unit, onNavigate: (String) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 22.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Bonjour, administrateur", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Voici l'état de votre activité.", color = Muted, fontSize = 13.sp)
                }
                Box(Modifier.background(Color(0xFF183B39), RoundedCornerShape(20.dp)).padding(horizontal = 10.dp, vertical = 7.dp)) {
                    Text("ESSAI · 30 J", color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TrendingUp, null, tint = Mint)
                        Spacer(Modifier.width(8.dp))
                        Text("Chiffre d'affaires aujourd'hui", color = Muted, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("620 000 FG", color = White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(5.dp))
                    Text("Données de démonstration", color = Muted, fontSize = 11.sp)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard("Connectés", "86", Icons.Default.People, Modifier.weight(1f))
                MetricCard("Tickets vendus", "124", Icons.Default.ConfirmationNumber, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard("Routeurs actifs", "${routers.size}/10", Icons.Default.Router, Modifier.weight(1f))
                MetricCard("CPU moyen", "18 %", Icons.Default.Memory, Modifier.weight(1f))
            }
        }
        item { SectionHeading("Mes routeurs", "Voir tout") { onNavigate("Routeurs") } }
        items(routers.take(3)) { router ->
            RouterCard(router)
        }
        item {
            OutlinedButton(
                onClick = onAddRouter, modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Mint)
            ) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Ajouter un routeur")
            }
        }
        item { SectionHeading("Accès rapide", null, {}) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction("Générer tickets", Icons.Default.ConfirmationNumber, Modifier.weight(1f)) { onNavigate("Tickets") }
                QuickAction("Voir rapports", Icons.Default.BarChart, Modifier.weight(1f)) { onNavigate("Ventes & rapports") }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp)) {
            Icon(icon, null, tint = Mint, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(10.dp))
            Text(value, color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SectionHeading(title: String, action: String?, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        if (action != null) Text(action, color = Mint, fontSize = 12.sp, modifier = Modifier.clickable { onClick() })
    }
}

@Composable
private fun RouterCard(name: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Panel2, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Router, null, tint = Mint)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text("CPU 18 %  •  RAM 42 %", color = Muted, fontSize = 11.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(Mint, CircleShape))
                Spacer(Modifier.width(5.dp))
                Text("En ligne", color = Mint, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier.clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Panel2), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), horizontalAlignment = Alignment.Start) {
            Icon(icon, null, tint = Mint)
            Spacer(Modifier.height(10.dp))
            Text(label, color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun RouterScreen(routers: List<String>, onAddRouter: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Mes routeurs", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("${routers.size} routeur(s) sur 10 maximum", color = Muted)
        routers.forEach { RouterCard(it) }
        Button(onClick = onAddRouter, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink)) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Ajouter un routeur")
        }
        Text("La connexion distante réelle sera activée après configuration du serveur sécurisé.", color = Orange, fontSize = 12.sp)
    }
}

@Composable
private fun TicketScreen(tickets: List<String>, profiles: List<HotspotProfile>, onGenerate: () -> Unit, onDelete: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(4.dp))
        Text("Tickets Wi-Fi", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Créer, consulter et supprimer les codes.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Button(onClick = onGenerate, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Générer des tickets")
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            items(tickets.toList()) { ticket ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ConfirmationNumber, null, tint = Mint)
                        Spacer(Modifier.width(10.dp))
                        Text(ticket, color = White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        IconButton(onClick = { onDelete(ticket) }) { Icon(Icons.Default.DeleteOutline, "Supprimer", tint = Color(0xFFFF7F86)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfilesScreen(profiles: List<HotspotProfile>, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Profils Hotspot", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Définis librement tes durées, tarifs, débits et quotas.", color = Muted, fontSize = 13.sp)
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink)) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Créer mon profil")
        }
        profiles.forEach { profile ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).background(Panel2, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Schedule, null, tint = Mint)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(profile.name, color = White, fontWeight = FontWeight.Bold)
                        Text("Validité ${profile.validity} · ${profile.speed}", color = Muted, fontSize = 12.sp)
                        Text("Prix : ${profile.price} FG · Data : ${profile.dataLimit}", color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
        Text("Attention : ces profils sont encore locaux. Ils ne sont pas encore créés sur le routeur MikroTik.", color = Orange, fontSize = 11.sp)
    }
}

@Composable
private fun ActivityScreen() {
    val events = listOf(
        Triple("Ticket utilisé", "MW-9Q4B · Cimenterie", "Il y a 2 min"),
        Triple("Connexion routeur", "MY WIFI — Hafia 2", "Il y a 8 min"),
        Triple("Ticket créé", "25 codes · Profil 24 heures", "Il y a 15 min"),
        Triple("Session terminée", "Client Hotspot", "Il y a 21 min")
    )
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Activités récentes", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        events.forEach { event ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).background(Mint, CircleShape))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(event.first, color = White, fontWeight = FontWeight.SemiBold)
                        Text(event.second, color = Muted, fontSize = 12.sp)
                    }
                    Text(event.third, color = Muted, fontSize = 10.sp)
                }
            }
        }
        Text("Événements de démonstration.", color = Orange, fontSize = 12.sp)
    }
}

@Composable
private fun ReportsScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Ventes & rapports", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Vue synthétique de votre activité.", color = Muted, fontSize = 13.sp)
        MetricCard("Recettes aujourd'hui", "620 000 FG", Icons.Default.Payments, Modifier.fillMaxWidth())
        MetricCard("Cette semaine", "3 850 000 FG", Icons.Default.DateRange, Modifier.fillMaxWidth())
        MetricCard("Ce mois", "12 400 000 FG", Icons.Default.AccountBalanceWallet, Modifier.fillMaxWidth())
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Rapport", color = White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Tickets vendus : 124", color = Muted)
                Text("Dépenses déclarées : 150 000 FG", color = Muted)
                Text("Bénéfice estimé : 470 000 FG", color = Mint, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Les chiffres sont fictifs dans cette version prototype.", color = Orange, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun PortalScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Portail captif", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Choisissez le portail affiché aux clients.", color = Muted, fontSize = 13.sp)
        listOf("MY WIFI — Premium", "Minimal sombre", "Classique MikroTik").forEachIndexed { i, name ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Web, null, tint = Mint)
                    Spacer(Modifier.width(12.dp))
                    Text(name, color = White, modifier = Modifier.weight(1f))
                    if (i == 0) Text("ACTIF", color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    else Text("Prévisualiser", color = Muted, fontSize = 11.sp)
                }
            }
        }
        Text("L'envoi réel du portail au routeur nécessite une connexion MikroTik configurée.", color = Orange, fontSize = 12.sp)
    }
}

@Composable
private fun SettingsScreen() {
    val options = listOf(
        "Configuration réseau" to "IP, DHCP, DNS, interfaces",
        "Hotspot" to "Serveurs, profils, utilisateurs",
        "Pare-feu & NAT" to "Règles et redirections",
        "Wi-Fi & interfaces" to "Paramètres radio compatibles",
        "Sauvegardes" to "Exporter et restaurer une configuration",
        "Sécurité distante" to "Connexion chiffrée et accès autorisés"
    )
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Paramètres MikroTik", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Organisation des réglages par catégorie.", color = Muted, fontSize = 13.sp)
        options.forEach { option ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
                Row(Modifier.fillMaxWidth().clickable { }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Settings, null, tint = Mint)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(option.first, color = White, fontWeight = FontWeight.SemiBold)
                        Text(option.second, color = Muted, fontSize = 11.sp)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
        }
        Text("L'édition complète de RouterOS et l'accès distant seront implémentés dans la couche sécurisée du SaaS.", color = Orange, fontSize = 12.sp)
    }
}
